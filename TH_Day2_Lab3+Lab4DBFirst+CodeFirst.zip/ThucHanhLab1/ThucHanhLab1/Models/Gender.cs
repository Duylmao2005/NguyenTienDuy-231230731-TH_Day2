﻿namespace ThucHanhLab1.Models
{
    public enum Gender
    {
        Male, Female
    }
}
