﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;
using ThucHanhLab1.Models;

namespace ThucHanhLab1.ViewComponents
{
    public class BranchMenuViewComponent : ViewComponent
    {
        private readonly List<Branch> _branches = Enum.GetValues(typeof(Branch)).Cast<Branch>().ToList();

        public IViewComponentResult Invoke()
        {
            var model = _branches.Select(b => new SelectListItem
            {
                Text = b.ToString(),
                Value = b.ToString()
            }).ToList();

            return View(model);
        }
    }
}
