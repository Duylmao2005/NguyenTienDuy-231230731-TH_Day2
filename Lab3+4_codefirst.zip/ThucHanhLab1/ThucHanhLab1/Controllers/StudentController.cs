﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ThucHanhLab1.Models;

namespace ThucHanhLab1.Controllers
{
    [Route("Admin/Student")]
    public class StudentController : Controller
    {
        private List<Student> listStudents = new List<Student>();

        public StudentController()
        {
            listStudents = new List<Student>()
            {
                new Student(){Id=1, Name="Nguyen Van A", Email="A@gmail.com", Password="123456", Gender=Gender.Male, Branch=Branch.CE,
                    Address="Hanoi", DateOfBorth=new DateTime(2005,1,12), Score = 8.5, IsRegular=true},
                new Student(){Id=2, Name="Nguyen Thanh B", Email="B@yahoo.com", Password="123456", Gender=Gender.Female, Branch=Branch.IT,
                    Address="BacNinh", DateOfBorth=new DateTime(2005,5,1), Score = 10, IsRegular=true},
                new Student(){Id=3, Name="Nguyen Van C", Email="C@outlook.com", Password="123456", Gender=Gender.Male, Branch=Branch.BE,
                    Address="HaiPhong", DateOfBorth=new DateTime(2005,10,11), Score = 9.4, IsRegular=false},
                new Student(){Id=4, Name="Nguyen Thi D", Email="D@utc.edu.vn", Password="123456", Gender=Gender.Female, Branch=Branch.EE,
                    Address="TpHCM", DateOfBorth=new DateTime(2005,5,7), Score = 7, IsRegular=false},

            };

        }
        [Route("List", Name = "StudentList")]
        public IActionResult Index()
        {
            return View(listStudents);
        }

        [HttpGet]
        [Route("Add", Name = "CreateStudent")]
        public IActionResult Create()
        {
            ViewBag.AllGenders = Enum.GetValues(typeof(Gender)).Cast<Gender>().ToList();
            ViewBag.AllBranches = new List<SelectListItem>()
            {
                new SelectListItem { Text = "IT", Value = "1" },
                new SelectListItem { Text = "BE", Value = "2" },
                new SelectListItem { Text = "CE", Value = "3" },
                new SelectListItem { Text = "EE", Value = "4" }
            };
            return View();
        }

        [HttpPost]
        [Route("Add", Name = "CreateStudent")]
        public IActionResult Create(Student s)
        {
            if (ModelState.IsValid)
            {
                s.Id = listStudents.Last<Student>().Id + 1;
                listStudents.Add(s);
                return View("Index", listStudents);
            }
            ViewBag.AllGenders = Enum.GetValues(typeof(Gender)).Cast<Gender>().ToList();
            ViewBag.AllBranches = new List<SelectListItem>()
            {
                new SelectListItem { Text = "IT", Value = "1" },
                new SelectListItem { Text = "BE", Value = "2" },
                new SelectListItem { Text = "CE", Value = "3" },
                new SelectListItem { Text = "EE", Value = "4" }
            };
            return View();
        }
    }
}
