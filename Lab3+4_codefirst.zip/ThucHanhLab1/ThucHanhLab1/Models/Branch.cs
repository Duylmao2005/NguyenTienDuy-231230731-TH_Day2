﻿namespace ThucHanhLab1.Models
{
    public enum Branch
    {
        IT, BE, CE, EE
    }
}
